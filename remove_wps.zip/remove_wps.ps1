# 請以系統管理員身分執行此檔案！

Write-Host "🔧 開始移除 WPS Office，請稍候..." -ForegroundColor Yellow

# 1. 關閉相關進程
$wpsProcs = @("wps", "et", "wpp", "OTGContainer", "wpscloudsvr")
foreach ($p in $wpsProcs) {
    Get-Process -Name $p -ErrorAction SilentlyContinue | Stop-Process -Force
}

# 2. 卸載 WPS Office
$products = Get-WmiObject Win32_Product | Where-Object { $_.Name -like "*WPS*" }
foreach ($p in $products) {
    Write-Host "正在移除：$($p.Name)"
    $p.Uninstall()
}

# 3. 刪除 WPS 殘留資料夾
$folders = @(
    "$env:ProgramFiles\Kingsoft",
    "$env:ProgramFiles (x86)\Kingsoft",
    "$env:APPDATA\Kingsoft",
    "$env:LOCALAPPDATA\Kingsoft",
    "$env:APPDATA\VGX"
)

foreach ($f in $folders) {
    if (Test-Path $f) {
        Write-Host "刪除資料夾：$f"
        Remove-Item $f -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "✅ 移除完成，建議您重新啟動電腦。" -ForegroundColor Green
Pause